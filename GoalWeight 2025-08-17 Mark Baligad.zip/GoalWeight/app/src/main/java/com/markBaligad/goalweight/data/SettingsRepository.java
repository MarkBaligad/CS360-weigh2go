package com.markBaligad.goalweight.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class SettingsRepository {

    private final AppDatabaseHelper helper;

    public SettingsRepository(Context ctx) {
        this.helper = new AppDatabaseHelper(ctx);
    }

    public void setPhoneNumber(String phone) {
        put(AppDatabaseHelper.KEY_PHONE_NUMBER, phone == null ? "" : phone.trim());
    }

    public String getPhoneNumber() {
        return get(AppDatabaseHelper.KEY_PHONE_NUMBER);
    }

    public void setSmsTemplate(String template) {
        put(AppDatabaseHelper.KEY_SMS_TEMPLATE, template == null ? "" : template);
    }

    public String getSmsTemplate() {
        return get(AppDatabaseHelper.KEY_SMS_TEMPLATE);
    }

    public void put(String key, String value) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(AppDatabaseHelper.S_KEY, key);
        cv.put(AppDatabaseHelper.S_VAL, value);
        db.insertWithOnConflict(AppDatabaseHelper.T_SETTINGS, null, cv, SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
    }

    public String get(String key) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(AppDatabaseHelper.T_SETTINGS, new String[]{AppDatabaseHelper.S_VAL},
                AppDatabaseHelper.S_KEY + "=?", new String[]{key}, null, null, null);
        String value = null;
        if (c.moveToFirst()) value = c.getString(0);
        c.close();
        db.close();
        return (value == null || value.isEmpty()) ? null : value;
    }
}
