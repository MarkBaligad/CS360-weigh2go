package com.markBaligad.goalweight.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class GoalRepository {

    private final AppDatabaseHelper helper;

    public GoalRepository(Context ctx) {
        this.helper = new AppDatabaseHelper(ctx);
    }

    public void setGoalWeight(double goal) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(AppDatabaseHelper.S_KEY, AppDatabaseHelper.KEY_GOAL_WEIGHT);
        cv.put(AppDatabaseHelper.S_VAL, String.valueOf(goal));
        db.insertWithOnConflict(AppDatabaseHelper.T_SETTINGS, null, cv,
                SQLiteDatabase.CONFLICT_REPLACE);
        db.close();
    }

    public Double getGoalWeight() {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(AppDatabaseHelper.T_SETTINGS,
                new String[]{AppDatabaseHelper.S_VAL},
                AppDatabaseHelper.S_KEY + "=?",
                new String[]{AppDatabaseHelper.KEY_GOAL_WEIGHT},
                null, null, null);

        Double result = null;
        if (c.moveToFirst()) {
            try {
                result = Double.valueOf(c.getString(0));
            } catch (NumberFormatException ignored) { }
        }
        c.close();
        db.close();
        return result; // null if not set yet
    }
}
