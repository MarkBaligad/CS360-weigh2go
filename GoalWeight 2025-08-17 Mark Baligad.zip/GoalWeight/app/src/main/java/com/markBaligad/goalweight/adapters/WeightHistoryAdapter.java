package com.markBaligad.goalweight.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.markBaligad.goalweight.R;
import com.markBaligad.goalweight.models.WeightEntry;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class WeightHistoryAdapter extends RecyclerView.Adapter<WeightHistoryAdapter.ViewHolder> {

    // delete button
    public interface OnDeleteClickListener {
        void onDelete(WeightEntry entry, int position);
    }

    // Listener for delete and edit
    public interface OnItemClickListener {
        void onDeleteClick(WeightEntry entry, int position);
        void onEditClick(WeightEntry entry, int position);
    }

    private final List<WeightEntry> items;
    private final OnDeleteClickListener onDeleteClick;   // optional
    private final OnItemClickListener onItemClick;       // optional
    private final NumberFormat numberFormat;

    // Constructor for full listener (edit + delete)
    public WeightHistoryAdapter(List<WeightEntry> items, OnItemClickListener onItemClick) {
        this.items = items;
        this.onItemClick = onItemClick;
        this.onDeleteClick = null;
        this.numberFormat = NumberFormat.getNumberInstance(Locale.getDefault());
        this.numberFormat.setMaximumFractionDigits(1);
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateText;
        TextView weightText;
        View deleteBtn; // Button or ImageButton
        View editBtn;   // Button or ImageButton (optional)

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            dateText   = itemView.findViewById(R.id.textDate);
            weightText = itemView.findViewById(R.id.textWeight);

            // Works whether you used <Button> or <ImageButton>
            View maybeDelete = itemView.findViewById(R.id.button_delete);
            deleteBtn = (maybeDelete instanceof ImageButton || maybeDelete instanceof Button)
                    ? maybeDelete : null;

            View maybeEdit = itemView.findViewById(R.id.button_edit);
            editBtn = (maybeEdit instanceof ImageButton || maybeEdit instanceof Button)
                    ? maybeEdit : null;
        }
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_row, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry entry = items.get(position);

        holder.dateText.setText(entry.getDate());
        holder.weightText.setText(numberFormat.format(entry.getWeight()));

        // DELETE
        if (holder.deleteBtn != null) {
            holder.deleteBtn.setOnClickListener(v -> {
                int pos = holder.getAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) return;

                if (onItemClick != null) {
                    onItemClick.onDeleteClick(items.get(pos), pos);
                } else if (onDeleteClick != null) {
                    onDeleteClick.onDelete(items.get(pos), pos);
                }
            });
        }

        // EDIT
        if (holder.editBtn != null) {
            holder.editBtn.setOnClickListener(v -> {
                int pos = holder.getAdapterPosition();
                if (pos == RecyclerView.NO_POSITION) return;

                if (onItemClick != null) {
                    onItemClick.onEditClick(items.get(pos), pos);
                }
                // If only OnDeleteClickListener was provided, do nothing on edit.
            });
        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    // Helper APIs
    public WeightEntry getItem(int position) {
        return (position >= 0 && position < items.size()) ? items.get(position) : null;
    }

    public void removeItem(int position) {
        if (position >= 0 && position < items.size()) {
            items.remove(position);
            notifyItemRemoved(position);
        }
    }

    public void updateItem(int position, WeightEntry updated) {
        if (position >= 0 && position < items.size() && updated != null) {
            items.set(position, updated);
            notifyItemChanged(position);
        }
    }
}
