package com.markBaligad.goalweight.fragments;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.markBaligad.goalweight.R;
import com.markBaligad.goalweight.adapters.WeightHistoryAdapter;
import com.markBaligad.goalweight.data.WeightRepository;
import com.markBaligad.goalweight.models.WeightEntry;

import java.text.NumberFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class WeightHistoryFragment extends Fragment {

    private RecyclerView recyclerView;
    private WeightHistoryAdapter adapter;
    private final List<WeightEntry> weightList = new ArrayList<>();

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_weight_history, container, false);

        recyclerView = view.findViewById(R.id.weightHistoryRecyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Load from DB
        WeightRepository repo = new WeightRepository(requireContext());
        weightList.clear();
        weightList.addAll(repo.getAllDesc());

        // Listener for edit or delete button
        adapter = new WeightHistoryAdapter(weightList, new WeightHistoryAdapter.OnItemClickListener() {
            @Override
            public void onDeleteClick(WeightEntry entry, int position) {
                WeightRepository delRepo = new WeightRepository(requireContext());
                delRepo.delete(entry.getId());
                adapter.removeItem(position);
            }

            @Override
            public void onEditClick(WeightEntry entry, int position) {
                showEditDialog(entry, position);
            }
        });

        recyclerView.setAdapter(adapter);

        // FAB navigates to the Add Weight fragment
        FloatingActionButton fab = view.findViewById(R.id.fabAddWeight);
        fab.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.navigation_add_weight)
        );

        return view;
    }

    private void showEditDialog(WeightEntry entry, int position) {
        final EditText input = new EditText(requireContext());
        input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        // Prefill with current weight (localized)
        NumberFormat nf = NumberFormat.getNumberInstance(Locale.getDefault());
        nf.setMaximumFractionDigits(1);
        input.setText(nf.format(entry.getWeight()));
        input.setSelection(input.getText().length());
        input.setTextColor(android.graphics.Color.BLACK);

        new AlertDialog.Builder(requireContext())
                .setTitle(R.string.edit_weight) // make sure this string exists
                .setView(input)
                .setPositiveButton(R.string.save, (d, which) -> {
                    String raw = input.getText() == null ? "" : input.getText().toString().trim();
                    double newWeight;
                    try {
                        Number n = NumberFormat.getInstance(Locale.getDefault()).parse(raw);
                        if (n == null) throw new IllegalArgumentException("parse null");
                        newWeight = n.doubleValue();
                    } catch (Exception e) {
                        Toast.makeText(getContext(), R.string.enter_valid_number, Toast.LENGTH_SHORT).show();
                        return;
                    }

                    WeightRepository repo = new WeightRepository(requireContext());
                    boolean ok = repo.update(entry.getId(), entry.getDate(), newWeight);
                    if (ok) {
                        // Update in-memory list & notify adapter
                        weightList.set(position, new WeightEntry(entry.getId(), entry.getDate(), newWeight));
                        adapter.notifyItemChanged(position);
                        Toast.makeText(getContext(), R.string.update_successful, Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(getContext(), R.string.update_failed, Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }
}
