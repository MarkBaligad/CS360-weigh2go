package com.markBaligad.goalweight.fragments;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import com.markBaligad.goalweight.data.WeightRepository;
import com.markBaligad.goalweight.data.SettingsRepository;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import com.markBaligad.goalweight.R;
import androidx.navigation.Navigation;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;

public class AddWeightFragment extends Fragment {
    private static final String TAG = "SMS";
    private TextView tvTodaysDate;
    private EditText weightInput;
    double dailyWeight;
    private int phoneNumber = 0;
    private static final int SMS_PERMISSION_REQUEST_CODE = 101;

    // Empty constructor
    public AddWeightFragment() {
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_weight, container, false);

        // Get screen elements
        tvTodaysDate = view.findViewById(R.id.textViewTodaysDate);
        weightInput = view.findViewById(R.id.add_weight_input);
        Button saveButton = view.findViewById(R.id.edit_goal_weight_button);

        // Set today's date on the screen
        updateTodaysDate();

        // Request SMS permission
        requestSmsPermission();

        saveButton.setOnClickListener(v -> {
            String weightText = weightInput.getText().toString();

            // Edit Text cannot be empty
            if (weightText.isEmpty()) {
                Toast.makeText(getContext(), "Please enter your weight", Toast.LENGTH_SHORT).show();
                return;
            }

            // Confirm that the user entered a valid number
            double dailyWeight;
            try {
                java.text.NumberFormat nf = java.text.NumberFormat.getInstance(java.util.Locale.getDefault());
                dailyWeight = Objects.requireNonNull(nf.parse(weightText)).doubleValue();
            } catch (java.text.ParseException e) {
                Toast.makeText(getContext(), "Please enter a valid number", Toast.LENGTH_SHORT).show();
                return;
            }

            // Save entered weight
            boolean saveSuccess = saveWeightToDatabase(dailyWeight);

            if (saveSuccess) {
                double goalWeight = getUserGoalWeight();
                if (dailyWeight <= goalWeight) {
                    String phone = getUserPhoneNumber();
                    String msg = getSmsTemplate(goalWeight, dailyWeight);
                    if (phone != null) {
                        sendCongratulatorySms(phone, msg);
                    } else {
                        Toast.makeText(getContext(), msg, Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(getContext(), "Weight saved successfully", Toast.LENGTH_SHORT).show();
                }
                Navigation.findNavController(v).navigate(R.id.navigation_weight_history);
            }

        });


        return view;
    }

    private void updateTodaysDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("MMM d, yyyy", Locale.getDefault());
        String todayPretty = sdf.format(new Date());
        tvTodaysDate.setText(getString(R.string.todays_date, todayPretty));
    }


    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(),
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        }
    }

    private boolean saveWeightToDatabase(double dailyWeight) {
        WeightRepository repo = new WeightRepository(requireContext());
        // Use today's date in ISO-8601 (yyyy-MM-dd)
        String dateIso = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date());
        long id = repo.add(dateIso, dailyWeight);
        if (id <= 0) {
            Toast.makeText(getContext(), "Failed to save weight", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(getContext(), "Saved", Toast.LENGTH_SHORT).show();
        }
        // Return true if a record was created.
        return id > 0;
    }


    private double getUserGoalWeight() {
        com.markBaligad.goalweight.data.GoalRepository repo = new com.markBaligad.goalweight.data.GoalRepository(requireContext());
        Double g = repo.getGoalWeight();
        return g == null ? 200.0 : g; // default fallback
    }

    // Build the message
    private String getSmsTemplate(double goalWeight, double dailyWeight) {
        SettingsRepository sRepo = new SettingsRepository(requireContext());
        String tpl = sRepo.getSmsTemplate();
        if (tpl == null || tpl.trim().isEmpty()) {
            tpl = "Congratulations! You reached your goal weight of {goal} lbs (today: {weight}).";
        }
        NumberFormat nf = NumberFormat.getNumberInstance(Locale.getDefault());
        nf.setMaximumFractionDigits(1);
        return tpl.replace("{goal}", nf.format(goalWeight))
                .replace("{weight}", nf.format(dailyWeight));
    }

    private String getUserPhoneNumber() {
        SettingsRepository sRepo = new SettingsRepository(requireContext());
        String raw = sRepo.getPhoneNumber();
        if (raw == null) return null;
        String cleaned = raw.replaceAll("[^0-9+]", "");
        return cleaned.isEmpty() ? null : cleaned;
    }

    private void sendCongratulatorySms(String phoneNumber, String message) {
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(getContext(), "SMS permission not granted", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            SmsManager.getDefault().sendTextMessage(phoneNumber, null, message, null, null);
        } catch (Exception e) {
            // Fallback toast if sending fails
            Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
        }
    }
}
