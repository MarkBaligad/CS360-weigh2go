package com.markBaligad.goalweight.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.markBaligad.goalweight.R;
import com.markBaligad.goalweight.data.WeightRepository;
import com.markBaligad.goalweight.data.GoalRepository;
import com.markBaligad.goalweight.models.WeightEntry;

import java.text.NumberFormat;
import java.util.List;
import java.util.Locale;

public class DashboardFragment extends Fragment {

    private TextView tvLastWeight;
    private TextView tvGoalWeight;
    private TextView tvLbsToGoal;

    public DashboardFragment() { }

    @Override
    public @Nullable View onCreateView(@NonNull LayoutInflater inflater,
                                       @Nullable ViewGroup container,
                                       @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_dashboard, container, false);

        tvLastWeight = view.findViewById(R.id.textViewLastWeight);
        tvGoalWeight = view.findViewById(R.id.textViewGoalWeight);
        tvLbsToGoal  = view.findViewById(R.id.textViewLbsToGoalWeight);

        // Buttons → Navigation
        Button btnEditGoal   = view.findViewById(R.id.edit_goal_weight_button);
        Button btnAddWeight  = view.findViewById(R.id.add_daily_weight_button);
        Button btnHistory    = view.findViewById(R.id.weight_history_button);

        btnEditGoal.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.navigation_edit_goal));
        btnAddWeight.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.navigation_add_weight));
        btnHistory.setOnClickListener(v ->
                Navigation.findNavController(v).navigate(R.id.navigation_weight_history));

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshDashboard();
    }

    private void refreshDashboard() {
        // Format numbers
        NumberFormat nf = NumberFormat.getNumberInstance(Locale.getDefault());
        nf.setMaximumFractionDigits(1);

        // Last Weight from DB
        Double lastWeight = null;
        {
            WeightRepository wRepo = new WeightRepository(requireContext());
            List<WeightEntry> all = wRepo.getAllDesc();
            if (!all.isEmpty()) {
                lastWeight = all.get(0).getWeight();
            }
        }

        // Goal Weight from DB (settings table)
        Double goalWeight = null;
        {
            GoalRepository gRepo = new GoalRepository(requireContext());
            goalWeight = gRepo.getGoalWeight(); // returns null if not set yet
        }

        // Compute lbs to goal (default to zero if negative)
        Double toGoal = null;
        if (lastWeight != null && goalWeight != null) {
            double diff = lastWeight - goalWeight;
            toGoal = Math.max(0.0, diff);
        }

        // Apply to UI using your string resources
        tvLastWeight.setText(getString(
                R.string.dashboard_last_weight,
                lastWeight == null ? "--" : nf.format(lastWeight)));

        tvGoalWeight.setText(getString(
                R.string.dashboard_goal_weight,
                goalWeight == null ? "--" : nf.format(goalWeight)));

        tvLbsToGoal.setText(getString(
                R.string.dashboard_lbs_to_goal_weight,
                toGoal == null ? "--" : nf.format(toGoal)));
    }
}
