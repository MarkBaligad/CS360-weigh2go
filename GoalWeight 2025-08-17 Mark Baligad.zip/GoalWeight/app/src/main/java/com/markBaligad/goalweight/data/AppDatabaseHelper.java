package com.markBaligad.goalweight.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class AppDatabaseHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "app.db";
    // Bump to 2 so existing installs create the settings table via onUpgrade
    public static final int DB_VERSION = 2;

    // Users table
    public static final String T_USERS = "users";
    public static final String U_ID = "id";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD_HASH = "password_hash";
    public static final String U_SALT = "salt";
    public static final String U_CREATED_AT = "created_at";

    // Weights table
    public static final String T_WEIGHTS = "weights";
    public static final String W_ID = "id";
    public static final String W_DATE = "date";     // ISO-8601 yyyy-MM-dd
    public static final String W_WEIGHT = "weight"; // double
    public static final String W_UPDATED_AT = "updated_at";

    // Settings table (for goal weight and future app settings)
    public static final String T_SETTINGS = "settings";
    public static final String S_KEY = "k";
    public static final String S_VAL = "v";
    // Key names
    public static final String KEY_GOAL_WEIGHT = "goal_weight";
    public static final String KEY_PHONE_NUMBER = "phone_number";
    public static final String KEY_SMS_TEMPLATE = "sms_template";


    public AppDatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // Users table
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                U_USERNAME + " TEXT NOT NULL UNIQUE, " +
                U_PASSWORD_HASH + " TEXT NOT NULL, " +
                U_SALT + " TEXT NOT NULL, " +
                U_CREATED_AT + " INTEGER NOT NULL)");

        // Daily Weights Table
        db.execSQL("CREATE TABLE " + T_WEIGHTS + " (" +
                W_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                W_DATE + " TEXT NOT NULL, " +
                W_WEIGHT + " REAL NOT NULL, " +
                W_UPDATED_AT + " INTEGER NOT NULL)");

        // Create index on Weight and Date for faster retrieval
        db.execSQL("CREATE INDEX idx_weights_date ON " + T_WEIGHTS +
                "(" + W_DATE + " DESC)");

        // Settings Table
        db.execSQL("CREATE TABLE " + T_SETTINGS + " (" +
                S_KEY + " TEXT PRIMARY KEY, " +
                S_VAL + " TEXT NOT NULL)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS " + T_SETTINGS + " (" +
                    S_KEY + " TEXT PRIMARY KEY, " +
                    S_VAL + " TEXT NOT NULL)");
        }

    }
}
