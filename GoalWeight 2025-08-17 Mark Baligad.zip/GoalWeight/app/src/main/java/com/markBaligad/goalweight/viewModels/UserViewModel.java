package com.markBaligad.goalweight.viewModels;

public class UserViewModel {
}
