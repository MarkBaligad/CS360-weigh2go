package com.markBaligad.goalweight.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Locale;

public class UserRepository {
    private final AppDatabaseHelper helper;
    private final SecureRandom random = new SecureRandom();

    public UserRepository(Context context) {
        helper = new AppDatabaseHelper(context);
    }

    public boolean usernameExists(String username) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(AppDatabaseHelper.T_USERS,
                new String[]{AppDatabaseHelper.U_ID},
                AppDatabaseHelper.U_USERNAME + "=?",
                new String[]{username},
                null, null, null);
        boolean exists = c.moveToFirst();
        c.close();
        db.close();
        return exists;
    }

    public boolean addUser(String username, String plainPassword) {
        if (username == null || username.trim().isEmpty() ||
            plainPassword == null || plainPassword.isEmpty()) return false;

        if (usernameExists(username)) return false;

        byte[] salt = new byte[16];
        random.nextBytes(salt);
        String saltHex = toHex(salt);
        String hash = hashPassword(plainPassword, saltHex);
        long now = System.currentTimeMillis();

        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(AppDatabaseHelper.U_USERNAME, username);
        values.put(AppDatabaseHelper.U_PASSWORD_HASH, hash);
        values.put(AppDatabaseHelper.U_SALT, saltHex);
        values.put(AppDatabaseHelper.U_CREATED_AT, now);
        long id = db.insert(AppDatabaseHelper.T_USERS, null, values);
        db.close();
        return id != -1;
    }

    public boolean validateCredentials(String username, String plainPassword) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(AppDatabaseHelper.T_USERS,
                new String[]{AppDatabaseHelper.U_PASSWORD_HASH, AppDatabaseHelper.U_SALT},
                AppDatabaseHelper.U_USERNAME + "=?",
                new String[]{username},
                null, null, null);
        boolean ok = false;
        if (c.moveToFirst()) {
            String storedHash = c.getString(0);
            String saltHex = c.getString(1);
            String attemptHash = hashPassword(plainPassword, saltHex);
            ok = constantTimeEquals(storedHash, attemptHash);
        }
        c.close();
        db.close();
        return ok;
    }

    private String hashPassword(String password, String saltHex) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            md.update(hexToBytes(saltHex));
            byte[] digest = md.digest(password.getBytes());
            return toHex(digest);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    private boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) return false;
        if (a.length() != b.length()) return false;
        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }

    private String toHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format(Locale.US, "%02x", b));
        }
        return sb.toString();
    }

    private byte[] hexToBytes(String hex) {
        int len = hex.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2) {
            data[i / 2] = (byte) ((Character.digit(hex.charAt(i), 16) << 4)
                    + Character.digit(hex.charAt(i+1), 16));
        }
        return data;
    }
}
