package com.markBaligad.goalweight.activities;

import android.os.Bundle;
import android.telephony.PhoneNumberFormattingTextWatcher;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

import com.markBaligad.goalweight.R;
import com.markBaligad.goalweight.data.UserRepository;

public class RegistrationActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);

        EditText username = findViewById(R.id.create_username_input);
        EditText password = findViewById(R.id.create_password_input);
        EditText phonenumber = findViewById(R.id.create_phone_number_input);
        Button register = findViewById(R.id.create_account_button);

        //noinspection deprecation
        phonenumber.addTextChangedListener(new PhoneNumberFormattingTextWatcher()); // Automatically format input as a phone number

        UserRepository repo = new UserRepository(this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String sUserName = username.getText().toString().trim();
                String sUserPass = password.getText().toString();
                String sUserPhone = phonenumber.getText().toString().trim();

                if (TextUtils.isEmpty(sUserName) || TextUtils.isEmpty(sUserPass)) {
                    Toast.makeText(RegistrationActivity.this, "Please enter username and password", Toast.LENGTH_SHORT).show();
                    return;
                }
                if (repo.addUser(sUserName, sUserPass)) {
                    Toast.makeText(RegistrationActivity.this, "Account created. You can log in now.", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(RegistrationActivity.this, "Username taken or invalid", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
