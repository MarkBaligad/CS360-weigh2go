package com.markBaligad.goalweight.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.markBaligad.goalweight.models.WeightEntry;

import java.util.ArrayList;
import java.util.List;

public class WeightRepository {
    private final AppDatabaseHelper helper;

    public WeightRepository(Context ctx) {
        helper = new AppDatabaseHelper(ctx);
    }

    public long add(String dateIso, double weight) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(AppDatabaseHelper.W_DATE, dateIso);
        cv.put(AppDatabaseHelper.W_WEIGHT, weight);
        cv.put(AppDatabaseHelper.W_UPDATED_AT, System.currentTimeMillis());
        long id = db.insert(AppDatabaseHelper.T_WEIGHTS, null, cv);
        db.close();
        return id;
    }

    public boolean update(long id, String dateIso, double weight) {
        SQLiteDatabase db = helper.getWritableDatabase();
        ContentValues cv = new ContentValues();
        if (dateIso != null) cv.put(AppDatabaseHelper.W_DATE, dateIso);
        cv.put(AppDatabaseHelper.W_WEIGHT, weight);
        cv.put(AppDatabaseHelper.W_UPDATED_AT, System.currentTimeMillis());
        int rows = db.update(AppDatabaseHelper.T_WEIGHTS, cv, AppDatabaseHelper.W_ID + "=?",
                new String[]{ String.valueOf(id) });
        db.close();
        return rows > 0;
    }

    public boolean delete(long id) {
        SQLiteDatabase db = helper.getWritableDatabase();
        int rows = db.delete(AppDatabaseHelper.T_WEIGHTS, AppDatabaseHelper.W_ID + "=?",
                new String[]{ String.valueOf(id) });
        db.close();
        return rows > 0;
    }

    public List<WeightEntry> getAllDesc() {
        SQLiteDatabase db = helper.getReadableDatabase();
        Cursor c = db.query(AppDatabaseHelper.T_WEIGHTS,
                new String[]{ AppDatabaseHelper.W_ID, AppDatabaseHelper.W_DATE, AppDatabaseHelper.W_WEIGHT },
                null, null, null, null,
                AppDatabaseHelper.W_DATE + " DESC");
        List<WeightEntry> out = new ArrayList<>();
        while (c.moveToNext()) {
            long id = c.getLong(0);
            String date = c.getString(1);
            double w = c.getDouble(2);
            out.add(new WeightEntry(id, date, w));
        }
        c.close();
        db.close();
        return out;
    }
}
