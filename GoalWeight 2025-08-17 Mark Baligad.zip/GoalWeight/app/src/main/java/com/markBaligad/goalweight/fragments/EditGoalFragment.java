package com.markBaligad.goalweight.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import com.google.android.material.textfield.TextInputEditText;
import com.markBaligad.goalweight.R;
import com.markBaligad.goalweight.data.GoalRepository;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

public class EditGoalFragment extends Fragment {

    private TextInputEditText goalInput;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_edit_goal, container, false);

        goalInput = view.findViewById(R.id.edit_goal_weight_input);
        Button saveBtn = view.findViewById(R.id.edit_goal_weight_button);

        // Prefill current goal if present
        GoalRepository repo = new GoalRepository(requireContext());
        Double current = repo.getGoalWeight();
        if (current != null && goalInput != null) {
            NumberFormat nf = NumberFormat.getNumberInstance(Locale.getDefault());
            nf.setMaximumFractionDigits(1);
            goalInput.setText(nf.format(current));
        }

        saveBtn.setOnClickListener(v -> {
            String raw = (goalInput.getText() == null) ? "" : goalInput.getText().toString().trim();
            if (raw.isEmpty()) {
                Toast.makeText(getContext(), "Please enter a number", Toast.LENGTH_SHORT).show();
                return;
            }

            double goal;
            try {
                NumberFormat nf = NumberFormat.getInstance(Locale.getDefault());
                Number n = nf.parse(raw);
                if (n == null) throw new ParseException("null", 0);
                goal = n.doubleValue();
            } catch (ParseException e) {
                Toast.makeText(getContext(), "Please enter a valid number", Toast.LENGTH_SHORT).show();
                return;
            }

            if (goal <= 0) {
                Toast.makeText(getContext(), "Goal must be greater than 0", Toast.LENGTH_SHORT).show();
                return;
            }

            repo.setGoalWeight(goal);
            Toast.makeText(getContext(), "Goal weight saved", Toast.LENGTH_SHORT).show();

            // Navigate back to Dashboard
            Navigation.findNavController(v).navigate(R.id.navigation_dashboard);
            // Or: Navigation.findNavController(v).navigateUp();
        });

        return view;
    }
}
