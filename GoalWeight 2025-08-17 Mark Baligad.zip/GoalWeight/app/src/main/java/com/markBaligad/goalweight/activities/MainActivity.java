package com.markBaligad.goalweight.activities;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;
import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import com.markBaligad.goalweight.R;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MaterialToolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        BottomNavigationView navView = findViewById(R.id.nav_view);
        NavHostFragment navHostFragment = (NavHostFragment) getSupportFragmentManager()
                .findFragmentById(R.id.nav_host_fragment);

        if (navHostFragment != null) {
            NavController navController = navHostFragment.getNavController();

            AppBarConfiguration appBarConfig = new AppBarConfiguration.Builder(
                    R.id.navigation_dashboard, R.id.navigation_add_weight, R.id.navigation_weight_history)
                    .build();

            NavigationUI.setupActionBarWithNavController(this, navController, appBarConfig);
            NavigationUI.setupWithNavController(navView, navController);

            // Explicit handler since the bottom nav menu sometimes stopped responding
            navView.setOnItemSelectedListener(item -> {
                // Let NavigationUI try first
                boolean handled = androidx.navigation.ui.NavigationUI.onNavDestinationSelected(item, navController);
                if (!handled) {
                    int id = item.getItemId();
                    if (id == R.id.navigation_dashboard
                            || id == R.id.navigation_add_weight
                            || id == R.id.navigation_weight_history) {
                        try {
                            navController.navigate(id);
                            handled = true;
                        } catch (Exception ignored) { }
                    }
                }
                return handled;
            });

        }
    }


}